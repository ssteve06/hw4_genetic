from Backpack import Backpack
from Box import Box
from Population import Population


pop = Population(pop_size=20, max_gen=20)
pop.genetic_alg()
